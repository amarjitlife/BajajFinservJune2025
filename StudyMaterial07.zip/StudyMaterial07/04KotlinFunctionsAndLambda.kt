
package learnKotlin

//_________________________________________________________
// Function Type
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ) : Int = a + b
fun sub( a: Int, b: Int ) : Int = a - b

fun sum3( a: Int, b: Int, c: Int ) : Int = a + b + c

// Higher Order Functions
//		Functions Which Takes And/Or Returns Functions

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int 
// Polymorphic Function
//		Using Mechanism: By Passing Behaviour To Behaviour
fun calculator( a: Int, b: Int, operation: ( Int, Int ) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 111
	val b = 222 
	var result : Int

	result = calculator( a, b, ::sum )
	println("Result = $result" )

	result = calculator( a, b, ::sub )
	println("Result = $result" )		

	var something: (Int, Int) -> Int = ::sum

	result = something( 10, 20 )
	println("Result = $result" )		

	something = ::sub
	result = something( 10, 20 )
	println("Result = $result" )			

	// something = ::sum3
	// result = something( 10, 20, 30 )
	// println("Result = $result" )			

	var somethingAgain: (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator

	// Lambda Expression
	val sumLambda = { x: Int, y: Int -> x + y }
	val subLambda = { x: Int, y: Int -> x - y }

	result = calculator( a, b, sumLambda )
	println("Result = $result" )

	result = calculator( a, b, subLambda )
	println("Result = $result" )		

	result = calculator( a, b, { x: Int, y: Int -> x - y } )
	println("Result = $result" )		

	result = calculator( a, b, Int::plus )
	println("Result = $result" )		

	result = calculator( a, b, 
		operation = { x: Int, y: Int 
			-> x - y 
		} 
	)
	println("Result = $result" )		

	result = calculator( a, b )  { // Trailing Lambda Syntax
				x, y -> x - y 
			 } 

	println("Result = $result" )		

}



//_________________________________________________________

fun playWithLambdas() {
	val something: () -> Unit  = { println( 99 ) }
	something()

	var multiplyLambda: (Int, Int ) -> Int

	multiplyLambda = { a: Int, b: Int -> Int 
		a * b
	}

	multiplyLambda = { a, b -> 
		a * b
	}

	var doubleLambda = { a : Int -> 2 * a }
	doubleLambda = { it * 2 }

	var square: (Int) -> Int  = { it * it }
}

//_________________________________________________________

// Higher Order Functions
//		Functions Which Takes And/Or Returns Functions

fun chooseSteps( backward: Boolean) : (Int) -> Int {

	fun moveForward( start: Int ) : Int { return start + 1 }
	fun moveBackward( start: Int ) : Int { return start + 1 }

	return if ( backward ) :: moveBackward else ::moveForward
}

fun playWithChooseSteps( ) {
	val something: (Int) -> Int = chooseSteps( backward = true )
	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseSteps

	val somethingMore = something( 199 )
}

//_________________________________________________________

var some = 99 

fun doSomething(x: Int) {
	something = 100
	return something + x + some
}

//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithLambdas")
	playWithLambdas()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

