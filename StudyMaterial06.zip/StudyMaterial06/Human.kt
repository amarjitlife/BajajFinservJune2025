
package learnKotlin

//___________________________________________________
// DESIGN PRINCIPLE
//		Design Towards Abstract Types Rather Than Concrete Types

// Corolollary
//		Design Towards To Intefaces Rather Than Concrete Classes


// Abstract Type
//		Opeartion = { fly(), saveWorld() }
//		Range  = {}

interface Superpower {
	fun fly()
	fun saveWorld()
}

 class Spiderman : Superpower {
	override fun fly() 		= println("Fly Like Spiderman!")
	override fun saveWorld() = println("SaveWorld Like Spiderman!")
}

class Superman : Superpower {
	override fun fly() 		= println("Fly Like Superman!")
	override fun saveWorld() = println("SaveWorld Like Superman!")
}

open class Heman {
	open fun fly() 		= println("Fly Like Heman!")
	open fun saveWorld() = println("SaveWorld Like Heman!")
}

open class Wonderwoman {
	open fun fly() 		= println("Fly Like Wonderwoman!")
	open fun saveWorld() = println("SaveWorld Like Wonderwoman!")
}

//_________________________________________________________
// Using Inheritance
// class Human : Spiderman() {
// class Human : Superman() {
// class Human : Heman() {	
class Human : Wonderwoman() {	
	override fun fly() 		 = super.fly()
	override fun saveWorld() = super.saveWorld()
}

//_________________________________________________________
// Using Composition
//		Composition Is Alternative To Inheritance
class HumanBetter {
	// val power = Spiderman()
	// val power = Superman()
	val power = Heman()
	fun fly() 		 = power.fly()
	fun saveWorld()  = power.saveWorld()
}

//_________________________________________________________
// Using Composition
//		Composition Is Alternative To Inheritance
// BEST PRACTICE
//		Always Prefer Composition Over Inheritance

// Polymorphic Type
// Polymorphic HumanBest Class
class HumanBest {
	var power: Superpower? = null
	fun fly() 		 = power?.fly()
	fun saveWorld()  = power?.saveWorld()
}

//_________________________________________________________

fun playWithHumanBest() {
	val hb = HumanBest()
	hb.power = Spiderman()
	hb.fly()
	hb.saveWorld()

	hb.power = Superman()
	hb.fly()
	hb.saveWorld()

	hb power = null	
	hb.fly()
	hb.saveWorld()
}

//_________________________________________________________

fun playWithChoices() {
	val sp = Spiderman()
	sp.fly()
	sp.saveWorld()
}

//_________________________________________________________

fun playWithHuman() {
	val h = Human()
	h.fly()
	h.saveWorld()
}

//_________________________________________________________

fun playWithHumanBetter() {
	val hb = HumanBetter()
	hb.fly()
	hb.saveWorld()
}
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : playWithChoices")
	playWithChoices()

	println("\nFunction : playWithHuman")
	playWithHuman()

	println("\nFunction : playWithHumanBetter")
	playWithHumanBetter()

	println("\nFunction : playWithHumanBest")
	playWithHumanBest()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

