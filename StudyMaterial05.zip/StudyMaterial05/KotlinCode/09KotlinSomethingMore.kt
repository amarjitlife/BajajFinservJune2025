
package learnKotlin


//_________________________________________________________

// DESIGN CHOICE 01
enum class UIState { LOADING, SUCCESS, ERROR }

// DESIGN CHOICE 02
sealed class UIState {
	data object Loading: UIState()
	data class Success( val data: String ) : UIState()
	data class Error( val exception: Exception ) : UIState()
}

// TODO
// 		WRITE STATE MACHINE 
//			Design 01 : Using Enums
//			Design 02 : Using Sealed Classes

fun updateUI( state: UIState ) {
	when( state ) {
		is UIState.Loading -> showLoading()
		is UIState.Success -> showData( state.data ) 
		is UIState.Error   -> showError( state.error )
	}
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

