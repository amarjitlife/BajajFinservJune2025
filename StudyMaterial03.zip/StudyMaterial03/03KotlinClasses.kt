
package learnKotlin

//_________________________________________________________
// BEST PRACTICE
//		Classes Which Are Not Meant To Be Inherited 
//				Must Be Final

// In Kotlin
//		Classes Are Final By Default
//				Final Classes Can't Be Inherited
//		Classes Members Are Also Final By Default
//				You Can't Override

// In Java/C++
//		Classes Are Open By Default
//				Open Classes Can Be Inherited
//		Classes Members Are Also Open By Default
//				You Can Override

open class View {
	// Method: Member Function
	open fun click() = println("View Clicked!")
}

class Button: View() {
	override fun click() = println("Button Clicked!")
}

fun playWithButton() {
	val button = Button()
	button.click()
}

//_________________________________________________________

open class View1 {
	open fun click() = println("View1 Clicked!")
}

class Button1: View1() {
	override fun click() 	= println("Button1 Clicked!")
	fun doMagic() 			= println("Button1 doMagic!")
	fun playCricket() 		= println("Button1 Playing Cricket!")
}

fun View1.showOff() =  println("View1 ShowOff...")
// fun Button1.showOff() =  println("Button1 ShowOff...")

fun playWithExtensionsFunctions() {
	val view = View1()
	view.click()
	view.showOff()

	val button = Button1()
	button.click()
	button.doMagic()
	button.showOff()

	val vv: View1 = Button1()
	vv.click()
	vv.showOff()
}

fun playWithObjectTypes() {
	val vv: View1 = Button1()
	vv.click()
	// vv.doMagic()

	val parent: View1 = Button1()
	// parent.playCricket()
	val kiddu = parent as Button1
	kiddu.playCricket()
}

//_________________________________________________________

// In Kotlin
//		By Default
//		Interfaces As Well As Members Are Open

// In Kotlin and Java 8+ Onwards
//		Interface Member Function Can Have Default Implementation

//	DESIGN PRACTICES
//		Use Inteface Member Function With Default Implementations
//			In Rarest Rare Cases: Where Really Functionality Is Common To System

interface Clickable2 {
	fun click()

	//	Member Function With Default Implementation
	fun doMagic() = println("Clickable2 doMagic")
}

class Button2 : Clickable2 {
	override fun click() = println("Button2 Clicked!")
}

fun playWithButton2() {
	val button = Button2()
	button.click()
	button.doMagic()
}

//_________________________________________________________

interface Clickable3 {
	fun click()
	fun showOff() = println("Clickable3 ShowOff!!!")
}

interface Focusable3 {
	fun focus()
	fun showOff() = println("Focusable3 ShowOff!!!")
}

class Button3 : Clickable3, Focusable3 {
	override fun click() = println("Button3 Clicked!")
	override fun focus() = println("Button3 Focused!")

	override fun showOff() {
		println("Button3: showOff")
		// super.showOff()
		super<Focusable3>.showOff()
		super<Clickable3>.showOff()
	}
}

fun playWithButton3() {
	val button = Button3()
	button.click()
	button.focus()
	button.showOff()
}


//_________________________________________________________

enum class Colour {
	RED, GREEN, BLUE, YELLOW, PINK, ORANGE, UNKNOWN
}

fun mixColours( c1: Colour, c2: Colour ) = when( setOf( c1, c2 ) ) {
	setOf( Colour.BLUE, Colour.GREEN ) 		-> Colour.YELLOW
	setOf( Colour.RED,  Colour.YELLOW )		-> Colour.ORANGE
	else  -> throw Exception("Dirty Colour!")
}

// DESIGN PRINCIPLE
//		Exceptions Are Not That Exceptional Such That It Breaks Your Design

fun mixColoursAgain( c1: Colour, c2: Colour ) : Colour = when( setOf( c1, c2 ) ) {
		setOf( Colour.BLUE, Colour.GREEN ) 		-> Colour.YELLOW
		setOf( Colour.RED,  Colour.YELLOW )		-> Colour.ORANGE
		// else  -> throw Exception("Dirty Colour!")
		// else -> "Dirty Colour!"
		else -> Colour.UNKNOWN
}

fun playWithColourMixing() {
	println( mixColours( Colour.GREEN, Colour.BLUE ) )
	println( mixColours( Colour.YELLOW, Colour.RED ) )

	println( mixColoursAgain( Colour.GREEN, Colour.BLUE ) )
	println( mixColoursAgain( Colour.YELLOW, Colour.RED ) )
}

//_________________________________________________________

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr) : Expr

// Kotlin Idioms
fun evaluate( e: Expr ) : Int = when( e ) {
	is Num 	-> e.value
	is Sum 	-> evaluate( e.left ) + evaluate( e.right )
	else	-> throw IllegalArgumentException("Unknown Expression!")
		//error: 'when' expression must be exhaustive. Add an 'else' branch.
}

fun playWithEvaluate() {
	// 100 + 200
	println( evaluate( Sum( Num(100), Num(200 )) ))	
	// ( 100 + 200 ) + 1000
	println( evaluate( Sum( Sum( Num(100), Num(200 )), Num(1000) ) ) )
}

//_________________________________________________________

sealed class Exprn {
	class Num( val value: Int ) : Exprn()
	class Sum( val left: Exprn, val right: Exprn) : Exprn()
}

// // Kotlin Idioms
fun evaluateAgain( e: Exprn ) : Int = when( e ) {
	is Exprn.Num 	-> e.value
	is Exprn.Sum 	-> evaluateAgain( e.left ) + evaluateAgain( e.right )
	// else	-> throw IllegalArgumentException("Unknown Expression!")
		//error: 'when' expression must be exhaustive. Add an 'else' branch.
}

fun playWithEvaluateAgain() {
	// 100 + 200
	println( evaluateAgain( Exprn.Sum( Exprn.Num(100), Exprn.Num(200 )) ))	
	// ( 100 + 200 ) + 1000
	println( evaluateAgain( Exprn.Sum( Exprn.Sum( Exprn.Num(100), Exprn.Num(200 ))
													, Exprn.Num(1000) ) ) )
}

//_________________________________________________________

// Enum Can Have
//		1. Enum Is A Associative Type 
//				Enum Constants Can Have Additional State
//		2. Member Functions

//				Enum Constructor
enum class Color(val red: Int, val green: Int, val blue: Int) {
	// Enum Constant Values
	RED( 255, 0, 0 ), GREEN( 0, 255, 0 ), BLUE( 0, 0, 255 );

	//Member Functions
	fun rgb() = ( red * 256 + green ) * 256 + blue
}

fun playWithAssociativeEnum() {
	var color : Color = Color.RED

	println( "Color: ${color}" )
	println( "Color Red Component Value: ${color.red}" )
	println( "Color Green Component Value: ${color.green}" )
	println( "Color Blue Component Value: ${color.blue}" )	 

	var colorRGB = color.rgb()
	println("Color RGB Value: $colorRGB" )
}

//_________________________________________________________

// sealed interface Error

// sealed class IOError() : Error

// class FileReadError( val file: File ) : IOError()
// class DatabaseError( val source: DataSource ) : IOError()

// fun checkError( e: Error ) = when( e ) {
// 	is FileReadError -> { println("Error While File Reading!") }
// 	is DatabaseError -> { println("Error While Database Dealing!") }
// 	// else -> 
// }

//_________________________________________________________

// Leo Tolstoy famously wrote in Anna Karenina, 
// "All happy families are alike; each unhappy family is unhappy in its own way,".

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : playWithButton")
	playWithButton()

	println("\nFunction : playWithExtensionsFunctions")
	playWithExtensionsFunctions()

	println("\nFunction : playWithObjectTypes")
	playWithObjectTypes()

	println("\nFunction : playWithButton2")
	playWithButton2()

	println("\nFunction : playWithButton3")
	playWithButton3()

	println("\nFunction : playWithColourMixing")
	playWithColourMixing()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithEvaluateAgain")
	playWithEvaluateAgain()

	println("\nFunction : playWithAssociativeEnum")
	playWithAssociativeEnum()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

