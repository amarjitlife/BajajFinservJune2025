
fun main() {
	println("Hello World!!! Welcome To Android Training!!!")	
}

