
package leanKotlin

import java.util.TreeMap


fun helloWorld() {
	println("Hello World!!! Welcome To Android Training!!!")	
}

//_________________________________________________________

fun max( a: Int, b : Int ) : Int {
	// In Kotlin
	//		if-else Is An Expression Hence It Has Value

	// In C/C++/Java
	//		if-else Is A Statement
	return if ( a > b ) a else b
}

fun maximum( a: Int, b : Int ) : Any  = if ( a > b ) a else "Shahukh Khan"
	// error: return type mismatch: expected 'Int', 
	//			actual 'Comparable<*> & Serializable'.

fun playWithMax() {
	println( max( 100, 200 ) )
	println( max( 111, -200 ) )

	println( maximum( 100, 200 ) )
	println( maximum( 111, -200 ) )
}

//_________________________________________________________

fun playWithTypeInferencingAndBinding() {
	// Implicitly Inferred Type
	//1. Type Inferring From RHS
	//2. Inferred Type Binding With LHS
	var something = 10 
	println( something )

	// Explicilty Annotating Type Int
	val somethingAgain: Int = 10
	println( somethingAgain )

	val something1 = 90.90 // Default Type Is Double
	println( something1 )

	val somethingAgain1: Double = 90.90
	println( somethingAgain1 )

	val something2 = 90.90F
	println( something2 )

	val somethingAgain2: Float = 90.90F
	println( somethingAgain2 )

	val greeting = "Good Evening!"
	val greetingAgain: String = "Good Evening!"

	println( greeting )
	println( greetingAgain )
}


//_________________________________________________________

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Mutability

// Creating Person Class/Type Having 2 Properties
//		viz. name And isMarried
//		name Is Immutable Property
//		isMarried Is Mutable Property

class Person( val name: String, var isMarried: Boolean ) 

// Kotlin Compiler Will Generate Following Things
//	For Above Person Class
//		1. Two Member Variable Corresponding To Each Member Property
//		2. For Immutable Property Getter Generated
//		3. For Mutable Property Getter As Well As Setter Generated
//		4. Will Generate Constructor ( Memberwise Initialiser )

fun playWithPerson() {
	val gabbar = Person("Gabbar Singh", false )

	println( gabbar.name ) // gabbar.getName()
	// gabbar.name = "Gabbar"
			// name Can't Be Reassigned
	println( gabbar.isMarried ) // gabbar.getIsMarried()

	val basanti = Person("Basanti", false )
	println( basanti.name )

	println( basanti.isMarried ) // basanti.getIsMarried()
	basanti.isMarried = true  	 // basanti.setIsMarried()
	println( basanti.isMarried )
}

//_________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Creating Rectangle Class/Type Having 3 Properties

// Kotlin Compiler Will Generate Following Things
//		1. 2 Member Variable Corresponding To Each Member Property
//		2. For Immutable Property Getter Generated
//		4. Will Generate Constructor ( Memberwise Initialiser )

class Rectangle( val height: Int, val width: Int ) {
	val isSquare: Boolean 
		get() {
			return height == width
		}
}

fun playWithRectanlge() {
	val rectangle1 = Rectangle( 20, 40 )
	println( rectangle1.width ) 	// rectangle1.getWidth()
	println( rectangle1.height ) 	// rectangle1.getHeight()
	println( rectangle1.isSquare )

	val rectangle2 = Rectangle( 222, 222 )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )
}

//_________________________________________________________
// DESIGN PRINCIPLE
//		Design System Towards Deterministic Rather Than Non-Deterministic
//		Prefer Context-Free System Design Over Context-Aware Design

// Corollary
//		Always Prefer Adding All Branches Rather Than else(Default) Branch
//		else ( Branch ) Should Be Last Resort If Above Not Possible

// Colour Type
//		Range = { RED, GREEN, BLUE, YELLOW, PINK, ORANGE }
//		Operations = { }


enum class Colour {
	RED, GREEN, BLUE, YELLOW, PINK, ORANGE
}

fun getStringForColour( colour : Colour ) : String {
	// when Is A Type Safe Expression
	//		It Respect Type Defintioon
	return when( colour ) {
		Colour.RED 		-> "Red Colour..."
		Colour.GREEN 	-> "Green Colour..."
		Colour.BLUE		-> "Blue Colour..."
		Colour.YELLOW 	-> "Yellow Colour..."
		// Colour.YELLOW 	-> "Yellow Colour..."
		Colour.PINK 	-> "Pink Colour..."
		Colour.ORANGE	-> "Orange Colour..."
		// error: 'when' expression must be exhaustive. 
		//		Add the 'BLUE' branch or an 'else' branch.
		// else 			-> "Unknown Colour..."
			 // warning: 'when' is exhaustive so 'else' is redundant here.
	}
}

fun playWithColours() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )	
	println( getStringForColour( Colour.RED ) )
	println( getStringForColour( Colour.GREEN ) )
	println( getStringForColour( Colour.YELLOW ) )
}

//_________________________________________________________

fun getStringForColourAgain( colour : Colour )= when( colour ) {
		Colour.RED 		-> "Red Colour..."
		Colour.GREEN 	-> "Green Colour..."
		Colour.BLUE		-> "Blue Colour..."
		Colour.YELLOW 	-> "Yellow Colour..."
		// Colour.YELLOW 	-> 99	
		Colour.PINK 	-> "Pink Colour..."
		Colour.ORANGE	-> "Orange Colour..."
}

fun playWithColoursAgain() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )	
	println( getStringForColourAgain( Colour.RED ) )
	println( getStringForColourAgain( Colour.GREEN ) )
	println( getStringForColourAgain( Colour.YELLOW ) )
}

//_________________________________________________________

// In Kotlin
//		when( Expression ) 
//			// Here Expression Can Be Any Valid Kotlin Object

// In Java
//		Similar To when Is switch: 
//		Expresion Can Be Integer, String Or Enum Value
//		switch( Expression ) 

// In C/C++
//		Similar To when Is switch: Expresion Can Be Integer, String Or Enum Value
//		Expresion Can Be Integer Value
//		switch( Expression ) 

//		switch( Expression ) 
//			// Here Expression Can Be Any Valid Kotlin Object

// enum class Colour {
// 	RED, GREEN, BLUE, YELLOW, PINK, ORANGE
// }

fun mixColours( c1: Colour, c2: Colour ) = when( setOf( c1, c2 ) ) {
	setOf( Colour.BLUE, Colour.GREEN ) 		-> Colour.YELLOW
	setOf( Colour.RED,  Colour.YELLOW )		-> Colour.ORANGE
	else  -> throw Exception("Dirty Colour!")
}

// DESIGN PRINCIPLE
//		Exceptions Are Not That Exceptional Such That It Breaks Your Design

// fun mixColoursAgain( c1: Colour, c2: Colour ) : Colour = when( setOf( c1, c2 ) ) {
// 		setOf( Colour.BLUE, Colour.GREEN ) 		-> Colour.YELLOW
// 		setOf( Colour.RED,  Colour.YELLOW )		-> Colour.ORANGE
// 		// else  -> throw Exception("Dirty Colour!")
// 		// else -> "Dirty Colour!"
// 		else -> Colour.UNKNOWN
// }

fun playWithColourMixing() {
	println( mixColours( Colour.GREEN, Colour.BLUE ) )
	println( mixColours( Colour.YELLOW, Colour.RED ) )
}

//_________________________________________________________

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr) : Expr

fun eval( e: Expr ) : Int {
	// What Is The Type Of e ???
	//		Expr 
	if ( e is Num ) { // Smart Type Casting
		// What Is The Type Of e ???
		//		Num
		return e.value
	}
	// What Is The Type Of e ???
	//		Expr

	if ( e is Sum ) { // Smart Type Casting
		// What Is The Type Of e ???
		//		Sum
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEval() {
	// 100 + 200
	println( eval( Sum( Num(100), Num(200 )) ))	
	// ( 100 + 200 ) + 1000
	println( eval( Sum( Sum( Num(100), Num(200 )), Num(1000) ) ) )
}


//_________________________________________________________

// Kotlin Idioms
fun evalAgain( e: Expr ) : Int = if ( e is Num ) { // Smart Type Casting
		e.value
	} else if ( e is Sum ) { // Smart Type Casting
		evalAgain( e.left ) + evalAgain( e.right )
	} else {
		throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvalAgain() {
	// 100 + 200
	println( evalAgain( Sum( Num(100), Num(200 )) ))	
	// ( 100 + 200 ) + 1000
	println( evalAgain( Sum( Sum( Num(100), Num(200 )), Num(1000) ) ) )
}

//_________________________________________________________
// EXPERIMENT FOLLOWING CODE!!! MOMENT DONE RAISE FLAG!!!

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr) : Expr

// Kotlin Idioms
fun evaluate( e: Expr ) : Int = when( e ) {
	is Num 	-> e.value
	is Sum 	-> evaluate( e.left ) + evaluate( e.right )
	else	-> throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvaluate() {
	// 100 + 200
	println( evaluate( Sum( Num(100), Num(200 )) ))	
	// ( 100 + 200 ) + 1000
	println( evaluate( Sum( Sum( Num(100), Num(200 )), Num(1000) ) ) )
}

//_________________________________________________________

fun fizzBuzz( i: Int ) = when {
	i % 15 	== 0 -> "FizzBuzz"
	i %  5  == 0 -> "Fizz"
	i %  3  == 0 -> "Buzz"
	else -> "$i "
}

fun playWithFizzBuzz() {
	for( i in 1..100 ) {
		print( fizzBuzz(i) )
	}

	for( i in 100 downTo 1 step 2 ) {
		print( fizzBuzz( i) )
	}
}

//_________________________________________________________

// import java.util.TreeMap

fun iteratingOverMaps() {
	val binaryRepresentation = TreeMap<Char, String>()

	for ( character in 'A'..'F' ) {
		val binary = Integer.toBinaryString( character.code )
		binaryRepresentation[ character ] = binary 
	}

	for ( (letter, binary) in binaryRepresentation ) {
		println("$letter = $binary")
	}
}


//_________________________________________________________

fun isLetter( c: Char ) 	= c in 'a'..'z' || c in 'A'..'Z'
fun isNotDigit( c : Char )	= c !in '0'..'9'

fun usingInCheck() {
	println( isLetter( 'q' ) )
	println( isLetter( 'x' ) )	
}

fun recognize( c : Char ) = when( c ) {
	in '0'..'9' 				-> "It's Digit!"
	in 'a'..'z', in 'A'..'Z' 	-> "It's a Letter!"
	else 	-> "I Don't Know"
}

fun usingInCheckWithWhen() {
	println( recognize( '8') )
}

// DESIGN PRACTICE
//		Write Code For Reading!!!


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : helloWorld")
	helloWorld()

	println("\nFunction : playWithMax")
	playWithMax()

	println("\nFunction : playWithTypeInferencingAndBinding")
	playWithTypeInferencingAndBinding()

	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithRectanlge")
	playWithRectanlge()

	println("\nFunction : playWithColours")
	playWithColours()

	println("\nFunction : playWithColoursAgain")
	playWithColoursAgain()

	println("\nFunction : playWithColourMixing")
	playWithColourMixing()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithEvalAgain")
	playWithEvalAgain()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithFizzBuzz")
	playWithFizzBuzz()

	println("\nFunction : iteratingOverMaps")
	iteratingOverMaps()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}


//_________________________________________________________
//_________________________________________________________

https://github.com/amarjitlife/BajajFinservJune2025
https://github.com/amarjitlife/BajajFinservJune2025
https://github.com/amarjitlife/BajajFinservJune2025

//_________________________________________________________
//_________________________________________________________


