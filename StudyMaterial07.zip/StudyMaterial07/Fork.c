#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// fork() Creates Child Process
//	To Child Process We Use fork()
//		fork() Returns:
//		< 0 Faile To Create Child Proces
//		= 0 New Process Creation Successful
//		> 0 i.e. Process ID of Child Process To The Parent Process
int main() {
	printf("Before Forking!...\n");
	int childPID = fork();
	printf("After Forking!...\n");

	int stackData = 222;
	char processName[10] = "";
	switch( childPID ) {
	case -1:
		printf("\nForking Failed...");
		exit( EXIT_FAILURE );
	case 0: // This Code Runs In Child Process
		stackData = stackData * 3;
	default: // Parent Process
		sleep(5);
		break;
	}

	if( childPID == 0 ) strcpy(processName, "Child \n");
	else 				strcpy(processName, "Parent \n");

	printf("Process: %s", processName);

	printf("\nPID = %u, PPID = %u, stackData = %d\n",
		getpid(), getppid(), stackData);
	
	char ch = getchar();
	return 0;
}

