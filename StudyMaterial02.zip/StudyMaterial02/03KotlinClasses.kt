
package learnKotlin

//_________________________________________________________
// BEST PRACTICE
//		Classes Which Are Not Meant To Be Inherited 
//				Must Be Final

// In Kotlin
//		Classes Are Final By Default
//				Final Classes Can't Be Inherited
//		Classes Members Are Also Final By Default
//				You Can't Override

// In Java/C++
//		Classes Are Open By Default
//				Open Classes Can Be Inherited
//		Classes Members Are Also Open By Default
//				You Can Override

open class View {
	// Method: Member Function
	open fun click() = println("View Clicked!")
}

class Button: View() {
	override fun click() = println("Button Clicked!")
}

fun playWithButton() {
	val button = Button()
	button.click()
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : playWithButton")
	playWithButton()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

