
package learnKotlin

//_________________________________________________________

fun playWithKotlinCollections() {
	val set = hashSetOf(10, 20, 77, 33)
	val list = arrayListOf( 10, 20, 77, 99 )
	val map = hashMapOf( 1 to "One", 10 to "Ten", 5 to "Five" )

	println( set.javaClass )
	println( list.javaClass )
	println( map.javaClass )	

	val strings = listOf("Ding", "Dong", "Ting", "Tong")
	println( strings.javaClass )
	println( strings.last() )

	val numnbers = setOf( 99, 88, 88, 77, 99, 10 )
	println( numnbers.javaClass )
	println( numnbers.maxOrNull() )
}

// Function : playWithKotlinCollections
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// class java.util.Arrays$ArrayList
// Tong
// class java.util.LinkedHashSet
// 99

//_________________________________________________________

fun lastChar( string: String ) = string.get( string.length - 1 )

fun String.lastCharacter() = this.get( this.length - 1 )

fun playWithLastChar() {
	println( lastChar( "Hello World!") )
	println( lastChar( "My ID: 420") )

	println( "Hello World!".lastCharacter() )
	println( "My ID: 420".lastCharacter() )
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


fun main() {
	println("\nFunction : playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction : playWithLastChar")
	playWithLastChar()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

