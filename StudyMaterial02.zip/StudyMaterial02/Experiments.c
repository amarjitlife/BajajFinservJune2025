

#include <stdio.h>
#include <limits.h>


// Drivent By Defination
//		Type Defination

// Type Safe Code
int sum( int a, int b ) {
	signed int sum;

	if ( ( b > 0 ) && a > ( INT_MAX - b ) ||
		 ( b < 0 ) && a < ( INT_MIN - b ) ) {
		printf("\nCan't Calcualate Valid Arithmatic Sum");
		exit( 1 );
	} else {
		sum = a + b;
		return sum;
	}
}
