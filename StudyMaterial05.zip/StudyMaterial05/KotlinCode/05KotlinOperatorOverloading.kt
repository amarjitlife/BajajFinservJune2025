
package learnKotlin

import java.math.BigDecimal

//_________________________________________________________

data class Point( val x: Int, val y: Int ) {
	operator fun plus( other: Point ) : Point {
		return Point( x + other.x, y + other.y  )
	}

	override fun equals( other: Any? ) : Boolean {
		if ( other == null || other !is Point ) return false
		return other.x == x && other.y == y
	}
}

operator fun Point.times( factor : Int ) : Point {
	return Point( x * factor, y * factor )
}

operator fun Point.unaryMinus() : Point {
	return Point( -x, -y )
}

fun playWithOperatorOverloading() {
	val point1 = Point( 10, 20 )
	val point2 = Point( 100, 200 )

	val point3 = point1 + point2 // point1.plus( point2 )
	println( point1 )
	println( point2 )
	println( point3 )

	val point4 = point1 * 5 // point1.times( 5 )
	println( point4 )
	println( -point4 ) // point4.unaryMinus()

}


//_________________________________________________________

//import java.math.BigDecimal

operator fun BigDecimal.inc() = this + BigDecimal.ONE

fun playWithUniaryIncrement() {
	var bigZero = BigDecimal.ZERO

	println( bigZero )
	println( bigZero++ ) // bigZero.inc()
	println( ++bigZero ) // bigZero.inc()
}

//_________________________________________________________

class Person(val firstName: String, val lastName: String) : Comparable<Person> {
	override fun compareTo( other: Person ) : Int {
		return compareValuesBy( this, other, Person::lastName, Person::firstName)
	}
}

fun playWithComarisonOperators() {
	val alice = Person("Alice", "Smith")
	val bob = Person("Bob", "Johnson")

	println( alice < bob )
}

//_________________________________________________________

data class PointAgain( val x: Int, val y: Int )

operator fun PointAgain.get( index: Int ) : Int {
	return when( index ) {
		0 -> x
		1 -> y
		else -> throw IndexOutOfBoundsException("Index Out Of Range...")
	}
}

fun playWithIndexingOperator() {
	val point1 = PointAgain( 10, 20 )
	val point2 = PointAgain( 100, 200 )

	println( point1[0] )
	println( point1[1] )

	println( point2[0] )
	println( point2[1] )
}

//_________________________________________________________

data class MutablePoint( var x: Int, var y: Int )

operator fun MutablePoint.get( index: Int ) : Int {
	return when( index ) {
		0 -> x
		1 -> y
		else -> throw IndexOutOfBoundsException("Index Out Of Range...")
	}
}

operator fun MutablePoint.set( index: Int, value: Int ) {
	return when( index ) {
		0 -> x = value
		1 -> y = value
		else -> throw IndexOutOfBoundsException("Index Out Of Range...")
	}
}

fun playWithIndexingOperatorMutable() {
	val point1 = MutablePoint( 10, 20 )
	val point2 = MutablePoint( 100, 200 )

	println( point1[0] )
	println( point1[1] )

	point1[0] = 11 // point1.set( 0, 11 )
	point1[1] = 99 // point1.set( 1, 99 )

	println( point1[0] )
	println( point1[1] )

	println( point2[0] )
	println( point2[1] )

}

//_________________________________________________________

data class Rectangle( val upperLeft: Point, val lowerRight: Point )

operator fun Rectangle.contains( point: Point ) : Boolean {
	return  point.x in upperLeft.x until lowerRight.x &&
			point.y in upperLeft.y until lowerRight.y
}

fun playWithMembershipOperator() {
	val rpoint1 = Point( 10, 20 )
	val rpoint2 = Point( 100, 200 )

	val point1 = Point( 50, 50 )
	val point2 = Point( 250, 600 )

	val rectangle = Rectangle( rpoint1, rpoint2 )
	
	println( point1 in rectangle ) // rectangle.contains( point1 )
	println( point2 in rectangle ) // rectangle.contains( point2 )
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : playWithOperatorOverloading")
	playWithOperatorOverloading()

	println("\nFunction : playWithUniaryIncrement")
	playWithUniaryIncrement()

	println("\nFunction : playWithComarisonOperators")
	playWithComarisonOperators()

	println("\nFunction : playWithIndexingOperator")
	playWithIndexingOperator()

	println("\nFunction : playWithIndexingOperatorMutable")
	playWithIndexingOperatorMutable()

	println("\nFunction : playWithMembershipOperator")
	playWithMembershipOperator()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

