
package learnKotlin

//_________________________________________________________

data class Subject( val name: String, val grade: Char, val points: Double )

// class Person( val firstName: String, val lastName: String ) {
open class Person( val firstName: String, val lastName: String ) {
// open class Person( open val firstName: String, open val lastName: String ) {
	val fullName = "$firstName $lastName"
}

// class Student( val firstName: String, val lastName: String ) : Person( firstName, lastName ) {
// class Student(override val firstName: String, override val lastName: String ) : Person( firstName, lastName ) {

// Defining Constructor Taking 2 Arguments
//		Please Note We Are Not Using val/var Keywords
//			Because It To Be Used When Redefinition Required
open class Student( firstName: String, lastName: String ) : Person( firstName, lastName ) {
	val passsedSubjects: MutableList<Subject> = mutableListOf<Subject>()
	val failedSubjects : MutableList<Subject> = mutableListOf<Subject>()

	open fun printGrades() {
		for ( subject in passsedSubjects ) println("  $subject")
		for ( subject in failedSubjects ) println("  $subject")
	}

	fun recordGrades( subject: Subject) {
		if ( subject.grade == 'F' ) failedSubjects.add( subject )
		else passsedSubjects.add( subject )
	}

	fun isPassed() : Boolean = failedSubjects.size <= 2
}

fun playWithClassInheritance() {
	val gabbar = Student( "Gabbar", "Singh" )
	println( gabbar.firstName )
	println( gabbar.lastName )
	println( gabbar.fullName )

	gabbar.printGrades()
}

//_________________________________________________________

data class Game( val name: String, val grade: Char, val points: Double )

class StudentAthele( firstName: String, lastName: String ) : Student( firstName, lastName ) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGames( game: Game ) { gamesPlayed.add( game ) }
	override fun printGrades() {
		super.printGrades()
		for ( game in gamesPlayed ) println( "  $game" )
	}
}

fun playWithStudentAndGames() {
	val gabbar = StudentAthele( "Gabbar", "Singh" )
	val shooting = Game( "Shooting", 'A', 10.0 )
	val riding = Game( "Horse Riding", 'B', 9.0 )

	gabbar.recordGames( shooting )
	gabbar.recordGames( riding )
	gabbar.printGrades()
}


//_________________________________________________________

open class BandMember( firstName: String, lastName: String ) : Student( firstName, lastName ) {
	open val minimumPracticeTime : Int 
		get() { return 2 }
}

class GuitarPlayer( firstName: String, lastName: String ) : BandMember( firstName, lastName ) {
	override val minimumPracticeTime : Int
		get() { return 3 }
}

class FlutePlayer( firstName: String, lastName: String ) : BandMember( firstName, lastName ) {
	override val minimumPracticeTime : Int
		get() { return 3 }
}

//_________________________________________________________

fun playWithTypeChecking() {
	val guitarPlayer : GuitarPlayer = GuitarPlayer( "Arjit", "Singh" )
	// println( guitarPlayer )

	println( guitarPlayer is GuitarPlayer )
	println( guitarPlayer is BandMember )
	println( guitarPlayer is Student )
	println( guitarPlayer is Person )	

	val refer1 				= guitarPlayer
	val refer2 : BandMember = guitarPlayer
	val refer3 : Student 	= guitarPlayer
	val refer4 : Person   	= guitarPlayer

	println( refer1 is GuitarPlayer )
	println( refer1 is BandMember )
	println( refer1 is Student )
	println( refer1 is Person )	

	println( refer2 is GuitarPlayer )
	println( refer2 is BandMember )
	println( refer2 is Student )
	println( refer2 is Person )	

	println( refer3 is GuitarPlayer )
	println( refer3 is BandMember )
	println( refer3 is Student )
	println( refer3 is Person )	

	println( refer4 is GuitarPlayer )
	println( refer4 is BandMember )
	println( refer4 is Student )
	println( refer4 is Person )	
}


//_________________________________________________________

abstract class Mammal( val name: String, val birthDate: String ) {
	abstract fun consumeFood()
}

class Human( name: String, birthDate: String ) : Mammal( name, birthDate ) {
	override fun consumeFood() { println("Human Consuming Food!") }

	fun createBirthCertificate() = println("Birth Certificate: $birthDate ")
}

fun playWithMammals() {
	// error: cannot create an instance of an abstract class.
	// val lion = Mammal( "Lion", "10-10-10")
	// lion.consumeFood()

	val katrina = Human( "Katrina Kaif", "10-10-10")
	katrina.consumeFood()
	katrina.createBirthCertificate()

	println( katrina is Human )
	println( katrina is Mammal )
}

//_________________________________________________________

//	Primary Constructor
//		Constructor Defined Followed By Class Name
class PersonAgain1( val firstName: String, val lastName: String ) {
	val fullName: String = "$firstName $lastName"
}

//	Primary Constructor
//		Constructor Defined Followed By Class Name
//		constructor Keyword Is Optional
class PersonAgain2 constructor( val firstName: String, val lastName: String ) {
	val fullName: String = "$firstName $lastName"
}

fun playWithPrimaryConstructors() {
	val gabbar1 = PersonAgain1( "Gabbar", "Singh" )
	println( gabbar1.fullName )

	val gabbar2 = PersonAgain2( "Gabbar", "Singh" )
	println( gabbar2.fullName )
}

//_________________________________________________________

// Constructor Overloading
open class Shape {
	val boundaryColor: String
	val fillColor: String

	// constructor() {
	// 	this.boundaryColor = "Black"
	// 	this.fillColor 	   = "Unknown"
	// }

	constructor( boundaryColor : String ) {
		this.boundaryColor = boundaryColor
		this.fillColor 	   = "Unknown"
	}

	constructor( boundaryColor : String, fillColor: String ) {
		this.boundaryColor = boundaryColor
		this.fillColor 	   = fillColor
	}	

	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

fun playWithShapes() {
	val shape1 = Shape( "Black" )
	val shape2 = Shape( boundaryColor = "Black" )

	val shape3 = Shape( "Black", "Blue" )
	val shape4 = Shape( boundaryColor = "Black", fillColor = "Blue" )

	println( shape1 )
	println( shape2 )
	println( shape3 )
	println( shape4 )	
}

//_________________________________________________________

// Constructor With Default Arugments
open class ShapeBetter( val boundaryColor: String, val fillColor: String = "Unknown") {
	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

class CircleBetter( boundaryColor: String, fillColor: String = "Unknown", val radius : Int = 0)
	: ShapeBetter( boundaryColor, fillColor ) {
	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

fun playWithShapeBetter() {
	val shape1 = ShapeBetter( "Black" )
	val shape2 = ShapeBetter( boundaryColor = "Black" )

	val shape3 = ShapeBetter( "Black", "Blue" )
	val shape4 = ShapeBetter( boundaryColor = "Black", fillColor = "Blue" )

	println( shape1 )
	println( shape2 )
	println( shape3 )
	println( shape4 )	
}

//_________________________________________________________
/*
class Circle : Shape {
	var radius: Int = 0

	constructor( boundaryColor : String ) : super( boundaryColor ) {
		this.boundaryColor  = boundaryColor
		this.fillColor 	    = "Unknown"
		this.radius 		= 0
	}

	constructor( boundaryColor : String, fillColor: String ) : super( boundaryColor ) {
		this.boundaryColor  = boundaryColor
		this.fillColor 	    = "Unknown"
		this.radius 		= 0
	}

	constructor( boundaryColor : String, fillColor: String, radius : Int ) : super( boundaryColor ) {
	// constructor( boundaryColor : String, fillColor: String, radius : Int ) : this( boundaryColor, fillColor ) {
		this.boundaryColor = boundaryColor
		this.fillColor 	   = fillColor
		this.radius 		= 0
	}	

	override fun toString() = "Circle(boundaryColor=$boundaryColor, fillColor=$fillColor, radius=$radius)"
}

//_________________________________________________________

fun playWithCircle() {
	val circle1 = Circle( "Black" )
	val circle2 = Circle( boundaryColor = "Black" )
	val circle3 = Circle( "Black", "Blue" )
	val circle4 = Circle( "Black", "Blue", 99  )
	
	println( circle1 )
	println( circle2 )
	println( circle3 )
	println( circle4 )	
}
*/

//_________________________________________________________

// HOME WORK
//		Experiment Following Idea in Java Also
//				Reason Java Behvaiour
fun playWithLocalFunctionsAndClasses() { // Outside Function/Context
	var something = 10
	// Local Function: Function Defined Inside A Function
	fun doSomething() { // Inside Function/Context
		something = 111
	}

	// Local Class: Class Defined Inside A Function
	class Person( val firstName: String, val lastName: String ) { // Inside Context
		val sometingAgain = something + 100
		
		fun doSomething() {
			something = sometingAgain
		}
	}
	
	doSomething()
	val gabbar = Person( "Gabbar", "Singh")
	gabbar.doSomething()

	println("$something")
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : playWithClassInheritance")
	playWithClassInheritance()

	println("\nFunction : playWithStudentAndGames")
	playWithStudentAndGames()

	println("\nFunction : playWithTypeChecking")
	playWithTypeChecking()

	println("\nFunction : playWithMammals")
	playWithMammals()

	println("\nFunction : playWithPrimaryConstructors")
	playWithPrimaryConstructors()

	println("\nFunction : playWithShapes")
	playWithShapes()

	println("\nFunction : playWithShapeBetter")
	playWithShapeBetter()

	// println("\nFunction : playWithCircle")
	// playWithCircle()

	println("\nFunction : playWithLocalFunctionsAndClasses")
	playWithLocalFunctionsAndClasses()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

