package com.codepath.fragmentsdemo;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Static Fragments
        //setContentView(R.layout.activity_main_one);

        // Dynamic Fragments
         setContentView(R.layout.activity_main_two);
         setupViews();
    }

    private void setupViews() {
        Button button1 = (Button) findViewById(R.id.one_button);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // FragmentOne Will Create Small View Hierarchy i.e. View Tree
                // This View Hierarcy It Will Attach With View Hierarchy Created By Activity
                // Will Attach At Attach Piont
                replaceFragment(new FragmentOne());
            }
        });

        findViewById(R.id.two_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                replaceFragment(new FragmentTwo());
            }
        });
    }

    void replaceFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager()
                .beginTransaction();

        // Fragment Is Small Part of View Hierarchy
        // right_hand_side_container Is Our Attach Point
        // Will Attach View Hierarchy Created By Fragment At Attach Point
        transaction.replace(R.id.right_hand_side_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
