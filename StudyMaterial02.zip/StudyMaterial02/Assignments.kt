
_____________________________________________________

DAY 01
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]
	2. Collections Chapter 07 [ OPTIONAL ]

ASSIGNMENT A3: Revise, Practice Kotlin Code Done In Class
		String Type In C/C++, Python, Java, Kotlin, JavaScript, TypeScript?
			Unicode? Encoding? Memory Size?
			
_____________________________________________________

DAY 02
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	0. Chapter 01 [ MUST MUST MUST ]
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]
	2. Collections Chapter 07 [ OPTIONAL ]

_____________________________________________________

DAY 03
_____________________________________________________



_____________________________________________________
_____________________________________________________
_____________________________________________________
_____________________________________________________
