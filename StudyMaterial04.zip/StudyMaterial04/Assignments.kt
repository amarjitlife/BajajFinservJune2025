
_____________________________________________________

DAY 01
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]
	2. Collections Chapter 07 [ OPTIONAL ]

ASSIGNMENT A3: Revise, Practice Kotlin Code Done In Class
		String Type In C/C++, Python, Java, Kotlin, JavaScript, TypeScript?
			Unicode? Encoding? Memory Size?
			
_____________________________________________________

DAY 02
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	Core Java For Impatient
	0. Chapter 01 [ MUST MUST MUST ]
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]
	2. Collections Chapter 07 [ OPTIONAL ]

_____________________________________________________

DAY 03
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	Core Java For Impatient
	0. Chapter 01 [ MUST MUST MUST ]
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]

_____________________________________________________

DAY 04
_____________________________________________________


	Reference Link:: Object Class
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html


_____________________________________________________

DAY 05
_____________________________________________________


ASSIGNMENT A3: Read Assignments [ ADVANCED ]
	Reference Book: Effective Java
	1. Chapter 04: Classes and Interfaces [ MUST MUST MUST ]

_____________________________________________________
_____________________________________________________
_____________________________________________________
_____________________________________________________


https://github.com/amarjitlife/BajajFinservJune2025


