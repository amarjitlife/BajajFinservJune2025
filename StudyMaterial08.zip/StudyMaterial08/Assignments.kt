
_____________________________________________________

DAY 01
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]
	2. Collections Chapter 07 [ OPTIONAL ]

ASSIGNMENT A3: Revise, Practice Kotlin Code Done In Class
		String Type In C/C++, Python, Java, Kotlin, JavaScript, TypeScript?
			Unicode? Encoding? Memory Size?
			
_____________________________________________________

DAY 02
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	Core Java For Impatient
	0. Chapter 01 [ MUST MUST MUST ]
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]
	2. Collections Chapter 07 [ OPTIONAL ]

_____________________________________________________

DAY 03
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	Core Java For Impatient
	0. Chapter 01 [ MUST MUST MUST ]
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]

_____________________________________________________

DAY 04
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Thinking and Reading Assignments
	Reference Link:: Object Class
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html

_____________________________________________________

DAY 05
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Thinking and Problem Solving Assignments
	1. In Java class defined inside a class are inner by default and
		and In Kotlin class defined inside a class are nested by default
		WHY?
	2. How to create nested classes in Java?
	3. Where Should you use inner or nested classes?
	4. Can We Pass Function To Function In Java? If Yes Than How If Not Than Why?


ASSIGNMENT A3: State Machine Simualtion Design and Choices
			// DESIGN CHOICE 01
		enum class UIState { LOADING, SUCCESS, ERROR }

		// DESIGN CHOICE 02
		sealed class UIState {
			data object Loading: UIState()
			data class Success( val data: String ) : UIState()
			data class Error( val exception: Exception ) : UIState()
		}

		// TODO
		// 		WRITE STATE MACHINE 
		//			Design 01 : Using Enums
		//			Design 02 : Using Sealed Classes

		fun updateUI( state: UIState ) {
			when( state ) {
				is UIState.Loading -> showLoading()
				is UIState.Success -> showData( state.data ) 
				is UIState.Error   -> showError( state.error )
			}
		}


ASSIGNMENT A4: Read Assignments [ ADVANCED ]
	Reference Book: Effective Java
	1. Chapter 04: Classes and Interfaces [ MUST MUST MUST ]


ASSIGNMENT A4: Reading and Reasoning Assignments 
	Reference Link:: Object Class
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html

	Reference Link:: Android Components
		https://developer.android.com/guide/components/fundamentals


ASSIGNMENT A5: ANDROID CODE EXPLORATION AND REASONING ASSIGNMENT

	Download -> AndroidCode011.zip 
		├── AndroidCode011
		 		├── ActivitiesJava
				├── ConfigChangesJava
				├── ManifestAndResourcesJava

	Download -> AndroidCode021.zip 
		├── AndroidCode021
			 ├── Project.04.01.Layouts
			 ├── Project.04.04.Adapters

		├── AndroidCode021
			 ├── Project.04.03.Views


_____________________________________________________

DAY 06
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Android Code Done In Class

ASSIGNMENT A2: Coding and Thinking Following Android Example In Kotlin
		├── AndroidCode021
			 ├── Project.04.04.Adapters

		1. Write Good Code
		2. Restructure Code With Good Design
		3. What All Design choices Can Be Improved In ListView

ASSIGNMENT A3: Reading and Reasoning Assignments 
	Reference Link:: 
	https://developer.android.com/guide/platform
	https://developer.android.com/guide/components/activities/activity-lifecycle
	https://developer.android.com/develop/ui/views/layout/declaring-layout
	https://developer.android.com/guide/topics/resources/runtime-changes
	https://developer.android.com/guide/topics/manifest/activity-element

_____________________________________________________

DAY 07
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Android Code Done In Class

ASSIGNMENT A3: ANDROID CODE EXPLORATION AND REASONING ASSIGNMENT

		├── AndroidCode031
		│ └── Android.Code.Fragments
		│     ├── AndroidFragmentFundamentals
		│     └── AndroidFragmentPizza

		├── AndroidCode041
		│ 		├── Project.05.01.Intents
		│ 		└── Project.05.03.BroadcastIntents

ASSIGNMENT A3: Reading and Reasoning Assignments 
	Reference Link:: 
	https://guides.codepath.com/android/using-the-recyclerview
	https://developer.android.com/guide/fragments
	https://developer.android.com/develop/background-work/background-tasks/broadcasts
	https://developer.android.com/guide/components/intents-filters

_____________________________________________________

DAY 08
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Android Code Done In Class

ASSIGNMENT A3: Reading and Reasoning Assignments 
	Reference Link:: 
		https://developer.android.com/guide/components/intents-filters
		https://janisharali.com/blog/android-core-looper-handler-and-handlerthread-bd54d69fe91a
		https://developer.android.com/develop/background-work/services#Stopping
		https://developer.android.com/guide/components/processes-and-threads
		https://developer.android.com/develop/background-work/background-tasks
		https://janisharali.com/blog/android-core-looper-handler-and-handlerthread-bd54d69fe91a


READING ASSSIGNMENT A4 : [MUST MUST MUST]
	ANDROID APPLICATION MODERN ARCHITECHURE AND THINKING ASSIGNMENT
	https://developer.android.com/guide/components/fundamentals
	https://developer.android.com/topic/architecture/intro
	https://developer.android.com/topic/architecture
	https://developer.android.com/topic/architecture/ui-layer
	https://developer.android.com/topic/architecture/ui-layer/events
	https://developer.android.com/topic/architecture/domain-layer
	https://developer.android.com/topic/architecture/data-layer
	https://developer.android.com/topic/libraries/view-binding
	https://developer.android.com/topic/libraries/view-binding/migration
	https://developer.android.com/topic/libraries/data-binding#blog-posts
	https://developer.android.com/topic/libraries/data-binding/start
	https://developer.android.com/topic/libraries/data-binding/expressions

	ViewModel and LiveData
	https://developer.android.com/topic/libraries/architecture/viewmodel
	https://developer.android.com/topic/libraries/architecture/livedata
	https://developer.android.com/topic/libraries/architecture/saving-states

	Observer Pattern:
	https://en.wikipedia.org/wiki/Observer_pattern

	Kotlin Topics:
	https://kotlinlang.org/docs/scope-functions.html
	https://kotlinlang.org/docs/coroutines-guide.html
	https://developer.android.com/compose

CODE SAMPLES


CODE REFERNCES ASSIGNMENTS A5: ANDROID MODERN ARCHITECHURE
	https://developer.android.com/courses/android-basics-kotlin/course
	https://developer.android.com/courses/pathways/android-architecture

ASSSIGNMENT A6 : ANDROID APPLICATION MODERN ARCHITECTURE SAMPLES
	https://github.com/android/databinding-samples
	https://github.com/android/databinding-samples

	https://github.com/android/architecture-components-samples/tree/main/BasicSample
	https://github.com/android/architecture-components-samples

ASSSIGNMENT A7 : ANDROID APPLICATION MODERN ARCHITECTURE CODING ASSIGNMENTS
	https://codelabs.developers.google.com/codelabs/android-databinding
	https://developer.android.com/codelabs/android-lifecycles#0
	https://developer.android.com/codelabs/advanced-kotlin-coroutines#0
	https://developer.android.com/codelabs/android-workmanager#0
	https://developer.android.com/codelabs/android-adv-workmanager#0
	https://developer.android.com/codelabs/advanced-android-kotlin-training-custom-views#0

_____________________________________________________
_____________________________________________________
_____________________________________________________

https://github.com/amarjitlife/BajajFinservJune2025
_____________________________________________________

www.linkedin.com/in/amarjitlife
amarjitlife@gmail.com
+91 9980 777 145

_____________________________________________________



