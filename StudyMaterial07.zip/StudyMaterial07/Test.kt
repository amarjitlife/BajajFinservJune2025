open class View1 {
  open fun click() = println("View clicked")
}

class Button1 : View1() {
  override fun click() = println("Button clicked")
  fun doMagic() = println("Magic done!")
}

//Extension Functions
fun View1.showoff() = println("View is showing off....")
fun Button1.showoff() = println("Button is showing off....")

fun playWithExtensionsFunctions() {
  val btn = Button1()
  btn.click()
  btn.doMagic()
  btn.showoff()

  val view = View1()
  view.click()
  view.showoff()

  val vv:View1 = Button1()
  vv.click()
  vv.showoff()
}
//------------------------------------------------------------------
interface Click{
    fun click()
    fun showoff() = println("click showoff...")
}

interface Hover{
    fun hover()
    fun showoff() = println("hover showoff...")
}

class button : Click, Hover{
    override fun click() = println("Button click...")
    override fun hover() = println("Button hover...")
    override fun showoff(){
        println("button showoff...")
        super<Click>.showoff()
        super<Hover>.showoff()
    }
}

fun playWithButton(){
    val button = button()
    button.click()
    button.hover()
    button.showoff()
}

//--------------------------------------------------------------------
sealed class Exprn{
    class Num(val value: Int) : Exprn()
    class Sum(val left: Exprn, val right: Exprn): Exprn()
}

fun evaluate (e : Exprn) : Int = when (e){
    is Exprn.Num -> e.value
    is Exprn.Sum -> evaluate(e.left) + evaluate(e.right)
}

fun playWithEvaluate(){
    println(evaluate(Exprn.Sum(Exprn.Num(100), Exprn.Num(200))))
}
//--------------------------------------------------------------------

enum class Color(val red: Int, val green:Int, val blue:Int){
    RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255);
    
    fun rgb() = (red * 256 + green) * 256 + blue
}

fun playWithAssosateiveEnum(){
    var color : Color = Color.RED
    
    println("Color: ${color}")
    println("color green component value : ${color.green}")
    println("color blue component value : ${color.blue}")
    
    var colorRGB = color.rgb()
    println("Color RGB value: $colorRGB")
}
//--------------------------------------------------------------------

class File(name:String)
class DataSource( source:String )

sealed interface Error
sealed class IOError() : Error
class FileReadError(val file: File) : IOError()
class DataBaseError(val source: DataSource) : IOError()

fun handleError( e: Error ) = when(e){
    is FileReadError -> {println("Error while file reading...")}
    is DataBaseError -> {println("Error while database dealing...")}
    // error ->
    // error: 'when' expression must be exhaustive.
    //          Add the 'is DataBaseError' branch or an 'else' branch.
}

fun playWithHandleError(){
    val file = File(name = "data.txt")
    val source = DataSource(source="employee.db")
    
    val fileReadError = FileReadError(file)
    val dataBaseError = DataBaseError(source)
}
//--------------------------------------------------------------------
// interface IUser{
//     val nickName: String
// }

// class getFaceBookName(accountID : Int){
//     println(accountID)
// }

// class PrivateUser( override val nickName: String ) : IUser
// class SubscribedUser( val email: String ) : IUser{
//     override val nickName: String
//     get() = email.substringBefore('@')
// }

// class FaceBookUser( val accountID: Int ) : IUser {
//     override val nickName = getFaceBookName( accountID )
// }

// fun playWithInterfaceProperties(){
//     val gabbar = PrivateUser( "gabbar@ramgarh.com" )
//     println( gabbar.nickName )
    
//     val basanti = SubscribedUser( "basanti@ramgarh.com" )
//     println( basanti.nickName )
    
//     val thakur = FaceBookUser( 999 )
//     println( thakur.nickName )
// }
//--------------------------------------------------------------------

interface IUserAgain{
    val email: String 
    
    val nickName: String
        get() = email.substringBefore( '@' )
    
    var name: String
        get() = "Unknown"
        set( value ) {
            println("IUserAgain Setter called : $value")
        }
}

class Employee() : IUserAgain {
    override val email: String = "gabbar@ramgarh.com"
    override var name: String = "Unnamed"
        set( value ) {
            println("Employee name Setter called : $value ")
        }
}

fun playWithInterfacePropertiesAgain(){
    val gabbar = Employee()
    println("Name: ${gabbar.name}")
    gabbar.name = "Gabbar Singh"
    println("Name: ${gabbar.name}")
    
    println("Nickname: ${gabbar.nickName}")
    println("Email ID: ${gabbar.email}")
}
//--------------------------------------------------------------------

class UserAgain(val name: String){
    var address: String = "Unspecified"
        get() {
            println("Getter called - Address field : $field")
            return field
        }
        
        set(value){
            println("Setter called - Address Field: $field")
            field = value
            println("Setter calaled - Address Field: $field")
        }
}

fun playWithMemberVariableForProperty() {
    val gabbar = UserAgain("Gabber Singh")
    println( gabbar.name )
    println( gabbar.address )
    
    gabbar.address = "Ramgarh, Karnataka"
    println( gabbar.address )
}

//--------------------------------------------------------------------
class UserOnceAgain{
    var name: String = "Unnamed"
    var address: String = "Unspecified"
        get(){
            // println("Getter called - Address Field: ${address}")
            println("Getter called - Address Field: $field")            
            return field
        }
        
        set( value: String ){
            println("Setter called - Address Field: ${address}")
            field = value
            println("Setter called - Address Field: ${address}")
        }
}

fun playWithMemberVariableForPropertyAgain() {
    val gabbar = UserOnceAgain()
    println( gabbar.name)
    println( gabbar.address)
    
    gabbar.name = "Gabbar Singh"
    gabbar.address = "Ramgarh, Karnataka"
    
    println( gabbar.name )
    println( gabbar.address )
}

//====================================================================
fun main(){
    println("\nFunction : playWithExtensionsFunctions()")
    playWithExtensionsFunctions()
    println("\nFunction : playWithButton()")
    playWithButton()
    println("\nFunction : playWithEvaluate()")
    playWithEvaluate()
    println("\nFunction : playWithAssosateiveEnum()")
    playWithAssosateiveEnum()
    println("\nFunction : playWithHandleError()")
    playWithHandleError()
    println("\nFunction : playWithConstructorWithDefaultArguments()")
    // playWithInterfaceProperties()
    println("\nFunction : playWithInterfacePropertiesAgain()")
    playWithInterfacePropertiesAgain()
    println("\nFunction : playWithMemberVariableForProperty()")
    playWithMemberVariableForProperty()
    println("\nFunction : playWithMemberVariableForPropertyAgain()")
    playWithMemberVariableForPropertyAgain()
//     println()
}