
package learnKotlin

//_________________________________________________________
// BEST PRACTICE
//		Classes Which Are Not Meant To Be Inherited 
//				Must Be Final

// In Kotlin
//		Classes Are Final By Default
//				Final Classes Can't Be Inherited
//		Classes Members Are Also Final By Default
//				You Can't Override

// In Java/C++
//		Classes Are Open By Default
//				Open Classes Can Be Inherited
//		Classes Members Are Also Open By Default
//				You Can Override

open class View {
	// Method: Member Function
	open fun click() = println("View Clicked!")
}

class Button: View() {
	override fun click() = println("Button Clicked!")
}

fun playWithButton() {
	val button = Button()
	button.click()
}

//_________________________________________________________

open class View1 {
	open fun click() = println("View1 Clicked!")
}

class Button1: View1() {
	override fun click() 	= println("Button1 Clicked!")
	fun doMagic() 			= println("Button1 doMagic!")
	fun playCricket() 		= println("Button1 Playing Cricket!")
}

fun View1.showOff() =  println("View1 ShowOff...")
// fun Button1.showOff() =  println("Button1 ShowOff...")

fun playWithExtensionsFunctions() {
	val view = View1()
	view.click()
	view.showOff()

	val button = Button1()
	button.click()
	button.doMagic()
	button.showOff()

	val vv: View1 = Button1()
	vv.click()
	vv.showOff()
}

fun playWithObjectTypes() {
	val vv: View1 = Button1()
	vv.click()
	// vv.doMagic()

	val parent: View1 = Button1()
	// parent.playCricket()
	val kiddu = parent as Button1
	kiddu.playCricket()
}

//_________________________________________________________

// In Kotlin
//		By Default
//		Interfaces As Well As Members Are Open

// In Kotlin and Java 8+ Onwards
//		Interface Member Function Can Have Default Implementation

//	DESIGN PRACTICES
//		Use Inteface Member Function With Default Implementations
//			In Rarest Rare Cases: Where Really Functionality Is Common To System

interface Clickable2 {
	fun click()

	//	Member Function With Default Implementation
	fun doMagic() = println("Clickable2 doMagic")
}

class Button2 : Clickable2 {
	override fun click() = println("Button2 Clicked!")
}

fun playWithButton2() {
	val button = Button2()
	button.click()
	button.doMagic()
}

//_________________________________________________________

interface Clickable3 {
	fun click()
	fun showOff() = println("Clickable3 ShowOff!!!")
}

interface Focusable3 {
	fun focus()
	fun showOff() = println("Focusable3 ShowOff!!!")
}

class Button3 : Clickable3, Focusable3 {
	override fun click() = println("Button3 Clicked!")
	override fun focus() = println("Button3 Focused!")

	override fun showOff() {
		println("Button3: showOff")
		// super.showOff()
		super<Focusable3>.showOff()
		super<Clickable3>.showOff()
	}
}

fun playWithButton3() {
	val button = Button3()
	button.click()
	button.focus()
	button.showOff()
}


//_________________________________________________________

enum class Colour {
	RED, GREEN, BLUE, YELLOW, PINK, ORANGE, UNKNOWN
}

fun mixColours( c1: Colour, c2: Colour ) = when( setOf( c1, c2 ) ) {
	setOf( Colour.BLUE, Colour.GREEN ) 		-> Colour.YELLOW
	setOf( Colour.RED,  Colour.YELLOW )		-> Colour.ORANGE
	else  -> throw Exception("Dirty Colour!")
}

// DESIGN PRINCIPLE
//		Exceptions Are Not That Exceptional Such That It Breaks Your Design

fun mixColoursAgain( c1: Colour, c2: Colour ) : Colour = when( setOf( c1, c2 ) ) {
		setOf( Colour.BLUE, Colour.GREEN ) 		-> Colour.YELLOW
		setOf( Colour.RED,  Colour.YELLOW )		-> Colour.ORANGE
		// else  -> throw Exception("Dirty Colour!")
		// else -> "Dirty Colour!"
		else -> Colour.UNKNOWN
}

fun playWithColourMixing() {
	println( mixColours( Colour.GREEN, Colour.BLUE ) )
	println( mixColours( Colour.YELLOW, Colour.RED ) )

	println( mixColoursAgain( Colour.GREEN, Colour.BLUE ) )
	println( mixColoursAgain( Colour.YELLOW, Colour.RED ) )
}

//_________________________________________________________

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr) : Expr

// Kotlin Idioms
fun evaluate( e: Expr ) : Int = when( e ) {
	is Num 	-> e.value
	is Sum 	-> evaluate( e.left ) + evaluate( e.right )
	else	-> throw IllegalArgumentException("Unknown Expression!")
		//error: 'when' expression must be exhaustive. Add an 'else' branch.
}

fun playWithEvaluate() {
	// 100 + 200
	println( evaluate( Sum( Num(100), Num(200 )) ))	
	// ( 100 + 200 ) + 1000
	println( evaluate( Sum( Sum( Num(100), Num(200 )), Num(1000) ) ) )
}

//_________________________________________________________

sealed class Exprn {
	class Num( val value: Int ) : Exprn()
	class Sum( val left: Exprn, val right: Exprn) : Exprn()
}

// // Kotlin Idioms
fun evaluateAgain( e: Exprn ) : Int = when( e ) {
	is Exprn.Num 	-> e.value
	is Exprn.Sum 	-> evaluateAgain( e.left ) + evaluateAgain( e.right )
	// else	-> throw IllegalArgumentException("Unknown Expression!")
		//error: 'when' expression must be exhaustive. Add an 'else' branch.
}

fun playWithEvaluateAgain() {
	// 100 + 200
	println( evaluateAgain( Exprn.Sum( Exprn.Num(100), Exprn.Num(200 )) ))	
	// ( 100 + 200 ) + 1000
	println( evaluateAgain( Exprn.Sum( Exprn.Sum( Exprn.Num(100), Exprn.Num(200 ))
													, Exprn.Num(1000) ) ) )
}

//_________________________________________________________

// Enum Can Have
//		1. Enum Is A Associative Type 
//				Enum Constants Can Have Additional State
//		2. Member Functions

//				Enum Constructor
enum class Color(val red: Int, val green: Int, val blue: Int) {
	// Enum Constant Values
	RED( 255, 0, 0 ), GREEN( 0, 255, 0 ), BLUE( 0, 0, 255 );

	//Member Functions
	fun rgb() = ( red * 256 + green ) * 256 + blue
}

fun playWithAssociativeEnum() {
	var color : Color = Color.RED

	println( "Color: ${color}" )
	println( "Color Red Component Value: ${color.red}" )
	println( "Color Green Component Value: ${color.green}" )
	println( "Color Blue Component Value: ${color.blue}" )	 

	var colorRGB = color.rgb()
	println("Color RGB Value: $colorRGB" )
}

//_________________________________________________________

class File(name: String)
class DataSource( source: String )

sealed interface Error
sealed class IOError() : Error
class FileReadError( val file: File ) : IOError()
class DatabaseError( val source: DataSource ) : IOError()

fun handleError( e: Error ) = when( e ) {
	is FileReadError -> { println("Error While File Reading!") }
	is DatabaseError -> { println("Error While Database Dealing!") }
	// else -> 
	//	error: 'when' expression must be exhaustive. 
	//			Add the 'is DatabaseError' branch or an 'else' branch.
}

fun playWithHandleError() {
	val file = File(name = "data.txt")
	val source = DataSource( source = "employee.db")
	
	val fileReadError = FileReadError(file)
	val databaseError = DatabaseError(source)

	handleError( fileReadError )
	handleError( databaseError )
}

//_________________________________________________________

// Sealed classes and interfaces represent restricted class hierarchies 
// that provide more control over inheritance. 

// All direct subclasses of a sealed class are known at compile time. 
// No other subclasses may appear outside a module within which 
// the sealed class is defined. 
// For example, third-party clients can't extend your sealed class 
// in their code. 

// Thus, each instance of a sealed class has a type from a limited set 
// that is known when this class is compiled.

// The same works for sealed interfaces and their implementations: 
// once a module with a sealed interface is compiled, 
// no new implementations can appear.

// In some sense, sealed classes are similar to enum classes:

// the set of values for an enum type is also restricted, 
// but each enum constant exists only as a single instance, 
// whereas a subclass of a sealed class can have multiple instances, 
// each with its own state.

//_________________________________________________________

// DESIGN PRINCIPLE
// 		Leo Tolstoy famously wrote in Anna Karenina, 
// 		"All happy families are alike; each unhappy family is unhappy in its own way,".

//_________________________________________________________

// Constructor With Default Argument Values
//		Always Prefer Constructor With Default Aguments Values
//				Over Constructor Overloading

class User( val nickName: String, val isSubscribed: Boolean = true )

fun playWithConstructorWithDefaultArguments() {
	val alice = User("Alice")
	println( alice.nickName )
	println( alice.isSubscribed )

	val gabbar = User("Gabbar Singh", isSubscribed = false)
	println( gabbar.nickName )
	println( gabbar.isSubscribed)
}

//_________________________________________________________

fun getFacebookName( accountID: Int ) = "FB:$accountID"

// Interfaces Can Have Property Members
// Defining Interface With Property Members
interface IUser { 
	val nickname: String
}

class PrivateUser( override val nickname : String ) : IUser
class SubscribingUser( val email: String ) : IUser {
	override val nickname : String 
		get() = email.substringBefore( '@' )
}

class FacebookUser( val accountID: Int ) : IUser {
	override val nickname = getFacebookName( accountID )
}

fun playWithInterfaceProperties() {
	val gabbar = PrivateUser( "gabbar@ramgarh.com" )
	println( gabbar.nickname )

	val basanti = SubscribingUser( "basanti@ramgarh.com" )
	println( basanti.nickname )

	val thakur = FacebookUser( 999 )
	println( thakur.nickname )
}

//_________________________________________________________

interface IUserAgain {
	val email: String
	val nickname: String 
		get() = email.substringBefore( '@' )

	var name : String
		get() = "Unknown"
		set( value ) {
			println(" IUserAgain Setter Called : $value" )
			// field = value
				// error: property in interface cannot have a backing field
				//		Backing Field Means Member Variable
		}
}

class Employee() : IUserAgain {
	override val email: String = "gabbar@ramgarh.com"
	override var name: String = "Unnamed"
		set( value ) {
			println(" Employee name Setter Called : $value" )
			field = value
		}
}

fun playWithInterfacePropertiesAgain() {
	val gabbar = Employee()

	println( "Name: ${gabbar.name}" )
	gabbar.name = "Gabbar Singh"
	println( "Name: ${gabbar.name}" )

	println( "Nickname: ${gabbar.nickname}" )
	println( "Email ID: ${gabbar.email}" )
}

//_________________________________________________________

// field Is Member Variable Corresponding To Property
//		Each Property Have Correponding Member Variable Called field.

// e.g. address Is A Property ( Mutable )
//		It Has 3 Things
//		1. Member Variable ( field )
//		2. Getter Member Function ( get )
//		3. Setter Member Function ( set )

// As We Are Definining Getter As Well As Setter For address Property
//		Compiler Will Not Generate These

// e.g. name Is A Property ( IMMutable )
//		It Has 2 Things
//		1. Member Variable ( field )
//		2. Getter Member Function ( get )

// As We Are NOT Definining Getter For name Property
//		Compiler Will Generate These

class UserAgain( val name: String) {
	var address: String = "Unspecified"
		get() {
			println("Getter Called - Address Field: $field" )
			return field
		}

		set( value : String ) {
			println("Setter Called - Address Field: $field" )			
			field = value
			println("Setter Called - Address Field: $field" )			
		}
}

fun playWithMemberVariableForProperty() {
	val gabbar = UserAgain("Gabbar Singh")
	println( gabbar.name )
	println( gabbar.address )

	gabbar.address = "Ramgarh, Karnatka"
	println( gabbar.address )
}

//_________________________________________________________

// e.g. name Is A Property ( Mutable )
//		It Has 3 Things Which Compiler Will Generate It!
//		1. Member Variable ( field )
//		2. Getter Member Function ( get )
//		3. Setter Member Function ( set )

class UserOnceAgain {
	var name: String = "Unnamed!"
	var address: String = "Unspecified!"
		get() { // Custom Getter
			println("Getter Called - Address Field: $field" )
			return field
		}

		set( value : String ) { // Custom Setter
			println("Setter Called - Address Field: $field" )			
			field = value
			println("Setter Called - Address Field: $field" )			
		}
}

fun playWithMemberVariableForPropertyAgain() {
	val gabbar = UserOnceAgain()
	println( gabbar.name )
	println( gabbar.address )

	gabbar.name = "Gabbar Singh"
	gabbar.address = "Ramgarh, Karnatka"

	println( gabbar.name )
	println( gabbar.address )
}


//_________________________________________________________

class LengthCounter {
	var counter : Int = 0
		private set

	fun addWord( word : String ) {
		counter = counter + word.length
	}
}

fun playWithLenthCounter( ) {
	val lengthCounter = LengthCounter()

	lengthCounter.addWord( "Hi!" )
	println( lengthCounter.counter )

	lengthCounter.addWord( "Hello!" )
	println( lengthCounter.counter )
}


//_________________________________________________________

// toString Function Comes From Parent Type Object ( In Java )
///		Which Is Equivalent to Any In Kotlin
class Client1( val name: String, val postalCode: Int ) {
	// fun toString() : String {
		// error: 'toString' hides member of supertype 'Any' and 
		//			needs an 'override' modifier.
	override fun toString() : String {
		return "Client1( name=$name, postalCode=$postalCode )"
	}
}

fun playWithObjectPrinting() {
	val salman = Client1( "Salman Khan", 898989 )

	println( salman.name )
	println( salman.postalCode )

	println( salman )
}


//_________________________________________________________

// toString Function Comes From Parent Type Object ( In Java )
///		Which Is Equivalent to Any In Kotlin
class Client2( val name: String, val postalCode: Int ) {
	// fun toString() : String {
		// error: 'toString' hides member of supertype 'Any' and 
		//			needs an 'override' modifier.
	override fun toString() : String {
		return "Client2( name=$name, postalCode=$postalCode )"
	}

	override fun equals( other: Any? ) : Boolean {
		if ( other == null || other !is Client2 ) return false
		return name == other.name && postalCode == other.postalCode
	}
}

fun playWithObjectEqualisation() {
	val salman1 = Client2( "Salman Khan", 898989 )
	val salman2 = Client2( "Salman Khan", 898989 )

	println( salman1 )
	println( salman2 )
	println( salman1 == salman2 ) 
	// Kotlin Compiler Will Generate salman1.equals( salman2 ) For Above Line
}

//_________________________________________________________
// Data Classes
//		Classes For Compiler Will Generate Following Functions With Logic
//		For Data Classes
//			1. toString: With All Properties
// 			2. equals: Will Compare All Properties
// 			3. hashCode and copy
//					Will Generate HashCode Based On All Immutable Properties

data class Client3( val name: String, val postalCode: Int ) 
// {
// 	// fun toString() : String {
// 		// error: 'toString' hides member of supertype 'Any' and 
// 		//			needs an 'override' modifier.
// 	override fun toString() : String {
// 		return "Client2( name=$name, postalCode=$postalCode )"
// 	}

// 	override fun equals( other: Any? ) : Boolean {
// 		if ( other == null || other !is Client2 ) return false
// 		return name == other.name && postalCode == other.postalCode
// 	}
// }

fun playWithDataClases() {
	val salman1 = Client3( "Salman Khan", 898989 )
	val salman2 = Client3( "Salman Khan", 898989 )

	println( salman1 )
	println( salman2 )
	println( salman1 == salman2 ) 
	// Kotlin Compiler Will Generate salman1.equals( salman2 ) For Above Line
}

//_________________________________________________________

data class Client4( val name: String, val postalCode: Int )  {
	// Compiler Will Not Generate toString Function
	override fun toString() : String { // Custom toString
		return "Client2( name=$name, postalCode=$postalCode )"
	}
}

fun playWithDataClasesAgain() {
	val salman1 = Client4( "Salman Khan", 898989 )
	val salman2 = Client4( "Salman Khan", 898989 )

	println( salman1 )
	println( salman2 )
	println( salman1 == salman2 ) 
	// Kotlin Compiler Will Generate salman1.equals( salman2 ) For Above Line
}

//_________________________________________________________

// Object Classes
//		Singleton Classes
//		It Will Create One Instance Of object Class
//			That Instance Name Will Be Same As Object Class

object India {
	val name = "Bharat"
	fun name() : String {
		return "Hindustan"
	}
}

fun playWithSingleton() {
	val data = India.name()
	println( data )
	println( India.name )
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : playWithButton")
	playWithButton()

	println("\nFunction : playWithExtensionsFunctions")
	playWithExtensionsFunctions()

	println("\nFunction : playWithObjectTypes")
	playWithObjectTypes()

	println("\nFunction : playWithButton2")
	playWithButton2()

	println("\nFunction : playWithButton3")
	playWithButton3()

	println("\nFunction : playWithColourMixing")
	playWithColourMixing()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithEvaluateAgain")
	playWithEvaluateAgain()

	println("\nFunction : playWithAssociativeEnum")
	playWithAssociativeEnum()

	println("\nFunction : playWithHandleError")
	playWithHandleError()

	println("\nFunction : playWithConstructorWithDefaultArguments")
	playWithConstructorWithDefaultArguments()

	println("\nFunction : playWithInterfaceProperties")
	playWithInterfaceProperties()

	println("\nFunction : playWithInterfacePropertiesAgain")
	playWithInterfacePropertiesAgain()

	println("\nFunction : playWithMemberVariableForProperty")
	playWithMemberVariableForProperty()

	println("\nFunction : playWithMemberVariableForPropertyAgain")
	playWithMemberVariableForPropertyAgain()

	println("\nFunction : playWithLenthCounter")
	playWithLenthCounter()

	println("\nFunction : playWithObjectPrinting")
	playWithObjectPrinting()

	println("\nFunction : playWithObjectEqualisation")
	playWithObjectEqualisation()

	println("\nFunction : playWithDataClases")
	playWithDataClases()

	println("\nFunction : playWithDataClasesAgain")
	playWithDataClasesAgain()

	println("\nFunction : playWithSingleton")
	playWithSingleton()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

