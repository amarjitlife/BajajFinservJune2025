
_____________________________________________________

DAY 01
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]
	2. Collections Chapter 07 [ OPTIONAL ]

ASSIGNMENT A3: Revise, Practice Kotlin Code Done In Class
		String Type In C/C++, Python, Java, Kotlin, JavaScript, TypeScript?
			Unicode? Encoding? Memory Size?
			
_____________________________________________________

DAY 02
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	Core Java For Impatient
	0. Chapter 01 [ MUST MUST MUST ]
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]
	2. Collections Chapter 07 [ OPTIONAL ]

_____________________________________________________

DAY 03
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Read Following Chapters From Java
	Core Java For Impatient
	0. Chapter 01 [ MUST MUST MUST ]
	1. Object-Oriented Programming Chapter 02 [ MUST MUST MUST ]

_____________________________________________________

DAY 04
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Thinking and Reading Assignments
	Reference Link:: Object Class
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html

_____________________________________________________

DAY 05
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Kotlin Code Done In Class

ASSIGNMENT A2: Thinking and Problem Solving Assignments
	1. In Java class defined inside a class are inner by default and
		and In Kotlin class defined inside a class are nested by default
		WHY?
	2. How to create nested classes in Java?
	3. Where Should you use inner or nested classes?
	4. Can We Pass Function To Function In Java? If Yes Than How If Not Than Why?


ASSIGNMENT A3: State Machine Simualtion Design and Choices
			// DESIGN CHOICE 01
		enum class UIState { LOADING, SUCCESS, ERROR }

		// DESIGN CHOICE 02
		sealed class UIState {
			data object Loading: UIState()
			data class Success( val data: String ) : UIState()
			data class Error( val exception: Exception ) : UIState()
		}

		// TODO
		// 		WRITE STATE MACHINE 
		//			Design 01 : Using Enums
		//			Design 02 : Using Sealed Classes

		fun updateUI( state: UIState ) {
			when( state ) {
				is UIState.Loading -> showLoading()
				is UIState.Success -> showData( state.data ) 
				is UIState.Error   -> showError( state.error )
			}
		}


ASSIGNMENT A4: Read Assignments [ ADVANCED ]
	Reference Book: Effective Java
	1. Chapter 04: Classes and Interfaces [ MUST MUST MUST ]


ASSIGNMENT A4: Reading and Reasoning Assignments 
	Reference Link:: Object Class
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html

	Reference Link:: Android Components
		https://developer.android.com/guide/components/fundamentals


ASSIGNMENT A5: ANDROID CODE EXPLORATION AND REASONING ASSIGNMENT

	Download -> AndroidCode011.zip 
		├── AndroidCode011
		 		├── ActivitiesJava
				├── ConfigChangesJava
				├── ManifestAndResourcesJava

	Download -> AndroidCode021.zip 
		├── AndroidCode021
			 ├── Project.04.01.Layouts
			 ├── Project.04.04.Adapters

		├── AndroidCode021
			 ├── Project.04.03.Views


_____________________________________________________

DAY 06
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Android Code Done In Class

ASSIGNMENT A2: Coding and Thinking Following Android Example In Kotlin
		├── AndroidCode021
			 ├── Project.04.04.Adapters

		1. Write Good Code
		2. Restructure Code With Good Design
		3. What All Design choices Can Be Improved In ListView

ASSIGNMENT A3: Reading and Reasoning Assignments 
	Reference Link:: 
	https://developer.android.com/guide/platform
	https://developer.android.com/guide/components/activities/activity-lifecycle
	https://developer.android.com/develop/ui/views/layout/declaring-layout
	https://developer.android.com/guide/topics/resources/runtime-changes
	https://developer.android.com/guide/topics/manifest/activity-element

_____________________________________________________

DAY 07
_____________________________________________________

ASSIGNMENT A1: Revise, Practice Android Code Done In Class

ASSIGNMENT A3: ANDROID CODE EXPLORATION AND REASONING ASSIGNMENT

		├── AndroidCode031
		│ └── Android.Code.Fragments
		│     ├── AndroidFragmentFundamentals
		│     └── AndroidFragmentPizza

		├── AndroidCode041
		│ 		├── Project.05.01.Intents
		│ 		└── Project.05.03.BroadcastIntents

ASSIGNMENT A3: Reading and Reasoning Assignments 
	Reference Link:: 
	https://guides.codepath.com/android/using-the-recyclerview
	https://developer.android.com/guide/fragments
	https://developer.android.com/develop/background-work/background-tasks/broadcasts
	https://developer.android.com/guide/components/intents-filters

_____________________________________________________

DAY 08
_____________________________________________________



_____________________________________________________
_____________________________________________________
_____________________________________________________

https://github.com/amarjitlife/BajajFinservJune2025
_____________________________________________________


