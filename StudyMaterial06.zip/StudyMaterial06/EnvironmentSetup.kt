
1. Download Following Zip File: Kotlin Compiler
	
	LINK : https://github.com/JetBrains/kotlin/releases/tag/v2.1.21
		kotlin-compiler-2.1.21.zip 

2. Copy kotlin-compiler-2.1.21.zip Documents/Compilers Directory
3. Unzip 		kotlin-compiler-2.1.21.zip 



