
package learnKotlin

//_________________________________________________________
//_________________________________________________________

fun playWithKotlinCollections() {
	val set = hashSetOf(10, 20, 77, 33)
	val list = arrayListOf( 10, 20, 77, 99 )
	val map = hashMapOf( 1 to "One", 10 to "Ten", 5 to "Five" )

	println( set.javaClass )
	println( list.javaClass )
	println( map.javaClass )	

	val strings = listOf("Ding", "Dong", "Ting", "Tong")
	println( strings.javaClass )
	println( strings.last() )

	val numnbers = setOf( 99, 88, 88, 77, 99, 10 )
	println( numnbers.javaClass )
	println( numnbers.maxOrNull() )
}

// Function : playWithKotlinCollections
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// class java.util.Arrays$ArrayList
// Tong
// class java.util.LinkedHashSet
// 99

//_________________________________________________________

fun lastChar( string: String ) = string.get( string.length - 1 )

// Extension Function
//		Use Case: To Add Additional Functionality In Existing Classes
//		lastCharacter() Is An Extension Function On Type String
fun String.lastCharacter() = this.get( this.length - 1 )

fun playWithLastChar() {
	println( lastChar( "Hello World!") )
	println( lastChar( "My ID: 420") )

	println( "Hello World!".lastCharacter() )
	println( "My ID: 420".lastCharacter() )
}


//_________________________________________________________
// Polymorphic Function
//		Function Takes Multiple Forms
//		Using Mechanisms
//			1. Generics
//			2. Default Arguments 

// Generics
//		Code Whihc Generate Code
// Generics Function
//		Function Which Will Genratre Function
// T Is Type Placeholder
//		T will be substituted With Type At Compile Time
fun <T> joinToString( 
	collection: Collection<T>,
	seperator: String = ", ",
	prefix: String = "",
	postfix: String = "",
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	} 

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( joinToString( names ))
	println( joinToString( names, " : " ))
	println( joinToString( names, " : ", " >>>> " ))
	println( joinToString( names, " # ", " >>> ", " <<< " ))
	println( joinToString( names, " ## ", " [ ", " ] " ))

	val numbers = listOf(10, 20, 30, 40, 50)
	println( joinToString( numbers ))
	println( joinToString( numbers, " : " ))
	println( joinToString( numbers, " : ", " >>>> " ))
	println( joinToString( numbers, " # ", " >>> ", " <<< " ))
	println( joinToString( numbers, " ## ", " [ ", " ] " ))
} 


//_________________________________________________________

fun <T> Collection<T>.joinToStringExtension( 
	seperator: String = ", ",
	prefix: String = "",
	postfix: String = "",
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	} 

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( names.joinToStringExtension() )
	println( names.joinToStringExtension(" : " ))
	println( names.joinToStringExtension( " : ", " >>>> " ))
	println( names.joinToStringExtension( " # ", " >>> ", " <<< " ))
	println( names.joinToStringExtension( " ## ", " [ ", " ] " ))

	// val numbers = listOf(10, 20, 30, 40, 50)
	// println( joinToString( numbers ))
	// println( joinToString( numbers, " : " ))
	// println( joinToString( numbers, " : ", " >>>> " ))
	// println( joinToString( numbers, " # ", " >>> ", " <<< " ))
	// println( joinToString( numbers, " ## ", " [ ", " ] " ))
} 

//_________________________________________________________
// Writing Wrapper API With Kotlin Style

fun Collection<String>.join( 
	seperator: String = ", ",
	prefix: String = "",
	postfix: String = "",
) = joinToStringExtension( seperator, prefix, postfix )


fun playWithJoinExtension() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( names.join() )
	println( names.join(" : " ))
	println( names.join( " : ", " >>>> " ))
	println( names.join( " # ", " >>> ", " <<< " ))
	println( names.join( " ## ", " [ ", " ] " ))
} 

//_________________________________________________________
// Extension Properties
//	 	lastChar Is An Extension Property(Immutable) On Type String

val String.lastChar: Char
	get() = get( length - 1 )

//	 	lastChar Is An Extension Property(Mutable) On Type StringBuilder
var StringBuilder.lastChar: Char 
	get() = get( length - 1 )
	set( value: Char ) {
		this.setCharAt( length - 1, value )
	}

fun playWithExtensionProperties() {
	println( "Kotlin".lastChar )
	val sb = StringBuilder( "Kotlin?" )
	sb.lastChar = '!'
	println( sb )
}

//_________________________________________________________

fun parsePath( path: String ) {
	val directory = path.substringBeforeLast( "/" )
	val fullName = path.substringAfterLast( "/" )

	val fileName = fullName.substringBeforeLast( "." )
	val extension = fullName.substringAfterLast( "." )

	println("Directory: $directory, Name: $fileName, Ext: $extension")
}

fun playWithStringFunctions() {
	val path = "/Users/someone/kotlin/things/chapters.docx"

	parsePath( path )
}

//_________________________________________________________

class User( val id: Int, val name: String, val address: String)

fun saveUser( user: User ) {
	// Validation
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User ${user.id} : Empty Name")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User ${user.id} : Empty Address")		
	}

	println("Saving User...: ${user.id}")
}

fun functionValidateUser() {
	saveUser( User( 111, "Shahrukh Khan", "Delhi Wale"))
}

//_________________________________________________________

// class User( val id: Int, val name: String, val address: String)

fun saveUserAgain( user: User ) { // Outside Function/Context
	// Validation Logic
	// Local Function
	//		Function Defined Inside A Function
	fun validate( user: User, value: String, fieldName: String ) { // Inside Function/Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User ${user.id} : Empty $fieldName")
		}
	}

	validate( user, user.name, "Name" )
	validate( user, user.address, "Address" )

	println("Saving User...: ${user.id}")
}

fun functionValidateUserAgain() {
	saveUserAgain( User( 111, "Shahrukh Khan", "Delhi Wale"))
}

//_________________________________________________________

// class User( val id: Int, val name: String, val address: String)

fun User.save( ) { // Outside Function/Context
	// Validation Logic
	// Local Function
	//		Function Defined Inside A Function
	fun validate( user: User, value: String, fieldName: String ) { // Inside Function/Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User ${user.id} : Empty $fieldName")
		}
	}

	validate( this, this.name, "Name" )
	validate( this, this.address, "Address" )

	println("Saving User...: ${this.id}")
}

fun playWithSaveUser() {
	User( 111, "Shahrukh Khan", "Delhi Wale").save()
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fun main() {
	println("\nFunction : playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction : playWithLastChar")
	playWithLastChar()

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithJoinExtension")
	playWithJoinExtension()

	println("\nFunction : playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction : playWithStringFunctions")
	playWithStringFunctions()

	println("\nFunction : functionValidateUser")
	functionValidateUser()

	println("\nFunction : functionValidateUserAgain")
	functionValidateUserAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_________________________________________________________
//_________________________________________________________

