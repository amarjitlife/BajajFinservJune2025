

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

//_________________________________________________________
// Drivent By Defination
//		Type Defination

// Type Safe Code
int sum( int a, int b ) {
	signed int sum;

	if ( ( b > 0 ) && a > ( INT_MAX - b ) ||
		 ( b < 0 ) && a < ( INT_MIN - b ) ) {
		printf("\nCan't Calcualate Valid Arithmatic Sum");
		exit( 1 );
	} else {
		sum = a + b;
		return sum;
	}
}

//_________________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() 	{ printf("\nDoing Bhangra..."); }
void doHipHop() 	{ printf("\nDoing Hip Hop"); }

void playWithHuman() {
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\nID 	: %d", gabbar.id );
	printf("\nName	: %s", gabbar.name );	
	gabbar.dance();

	Human alia = { 100, "Alia Bhat", doHipHop };
	printf("\nID 	: %d", alia.id );
	printf("\nName	: %s", alia.name );	
	alia.dance();
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


int main() {
	printf("\n\nFunction: playWithHuman");
	playWithHuman();

	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
	// printf("\n\n Function: ");
}
